﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony.Core
{
    public interface IEngine
    {

        void Start();

    }
}
