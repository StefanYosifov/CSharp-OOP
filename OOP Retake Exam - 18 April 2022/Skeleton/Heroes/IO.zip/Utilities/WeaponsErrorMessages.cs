﻿namespace Heroes.Utilities
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public static class WeaponsErrorMessages
    {
        public const string nameIsEmptyOrWhiteSpace = "Weapon type cannot be null or empty.";
        public const string durabilityIsBelowZero = "Durability cannot be below 0.";
        public const string weaponIsNull = "Weapon cannot be null.";
    }
}
