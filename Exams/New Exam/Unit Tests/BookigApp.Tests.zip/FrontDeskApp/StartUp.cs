﻿using System;

namespace FrontDeskApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
