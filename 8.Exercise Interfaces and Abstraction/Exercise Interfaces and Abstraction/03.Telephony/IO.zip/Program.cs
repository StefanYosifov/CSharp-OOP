﻿using System;

namespace _03.Telephony
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
