﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony.Models.Interfaces
{
    public interface IBrowsable
    {

        string BrowseUrl(string url);

    }
}
