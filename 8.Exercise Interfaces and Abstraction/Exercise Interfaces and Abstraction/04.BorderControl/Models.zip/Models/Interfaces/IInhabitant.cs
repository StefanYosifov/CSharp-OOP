﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControl.Models.Interfaces
{
    public interface IInhabitant
    {

        public string Id { get; }
    }
}
