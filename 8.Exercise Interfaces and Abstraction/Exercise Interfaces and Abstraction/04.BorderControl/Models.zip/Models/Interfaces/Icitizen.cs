﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControl.Models.Interfaces
{
    public interface Icitizen
    {


        string Name { get; }
        int Age { get; }
        string Id { get; }
    }
}
