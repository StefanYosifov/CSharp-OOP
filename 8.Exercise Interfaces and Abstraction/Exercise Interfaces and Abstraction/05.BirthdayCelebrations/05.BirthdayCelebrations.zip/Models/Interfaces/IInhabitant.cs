﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BirthdayCelebrations.Models.Interfaces
{
    public interface IInhabitant
    {

        public string Id { get; }
    }
}
