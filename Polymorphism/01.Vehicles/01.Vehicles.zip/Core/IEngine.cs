﻿namespace Vehicles.Engine
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public interface IEngine
    {
        void Start();
    }
}
