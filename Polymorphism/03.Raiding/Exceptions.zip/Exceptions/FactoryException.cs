﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Exceptions
{
    public static class FactoryException
    {

        private const string InvalidHeroOperation = "Invalid hero!";

        
    }
}
