﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals.Models.Interfaces
{
    public interface IAnimal
    {



        string Name { get;  }    

        string FavouriteFood { get; }

        

    }
}
